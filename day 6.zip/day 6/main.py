# write a program to bubble sort a list of numbers

# def bubble_sort(list1):  
#     for i in range(0,len(list1)-1):  
#         for j in range(len(list1)-1):  
#             if(list1[j]>list1[j+1]):  
#                 temp = list1[j]  
#                 list1[j] = list1[j+1]  
#                 list1[j+1] = temp  
#     return list1  

# array = []
# while True:
#     n = int(input("Enter the number : "))
#     if n == 0:
#         break
#     array.append(n)
 
# sortedData = bubble_sort(array)
# print("Sorted data is : ",sortedData)
 
 
 
 
 
 
 
 
 
# def bubble_sort(list1):  
#     for i in range(0,len(list1)-1):  
#         for j in range(len(list1)-1):  
#             if(list1[j]>list1[j+1]):  
#                 temp = list1[j]  
#                 list1[j] = list1[j+1]  
#                 list1[j+1] = temp  
#     return list1  

 
# string = 'csiplearninghub'
# string_list = list(string)
# sortedData = bubble_sort(string_list)
# sortedData.reverse()
# print(sortedData)

# string = "".join(string_list)
# print(string)



# list1 = eval(input("Enter the list : "))

# list2 = []

# for i in list1:
#     if i not in list2:
#         list2.append(i)

# print('First List : ',list1)
# print('Second List : ',list2)



# list1 = eval(input("Enter first list : "))

# list2 = eval(input("Enter second list : "))

# print(list1 + list2)



list1 = eval(input("Enter the list : "))


